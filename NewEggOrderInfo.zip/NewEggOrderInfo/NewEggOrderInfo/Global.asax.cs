﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;
using Newegg.Marketplace.SDK;
using Newegg.Marketplace.SDK.Base;
using Newegg.Marketplace.SDK.Order;
using Newegg.Marketplace.SDK.Order.Model;
using Newegg.Marketplace.SDK.Model;

namespace NewEggOrderInfo
{
    public class Global : HttpApplication
    {

        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            String settingsFile = Server.MapPath("~/setting.json");
            String folderMocks = Server.MapPath("~/Mocks/");
            APIConfig config = APIConfig.FromJsonFile(settingsFile);
            config.MockPath = folderMocks;
            APIClient client = new APIClient(config) { SimulationEnabled = true };


            Helper.Ordercall = new OrderCall(client);

        }



    }
}