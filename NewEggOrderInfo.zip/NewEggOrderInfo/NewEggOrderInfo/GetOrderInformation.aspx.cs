﻿using Newegg.Marketplace.SDK;
using Newegg.Marketplace.SDK.Base;
using Newegg.Marketplace.SDK.Order;
using Newegg.Marketplace.SDK.Order.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NewEggOrderInfo
{
    public partial class _Default : Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        public List<OrderInfo> GetOrderInfo(string[] orderIds)
        {

            // Create Request
            var orderreq = new GetOrderInformationRequest(new GetOrderInformationRequestCriteria()
            {
                OrderNumberList = orderIds

            });

            // Send your request and get response
            var response = Helper.Ordercall.GetOrderInformation(null, orderreq).Result;

            if (!response.IsSuccess)
            {
                displayNetworkError();
            }
            // Get data from the response
            GetOrderInformationResponseBody info = response.GetResponseBody();

            // Use the data pre you business
            return info?.OrderInfoList;

        }

        protected void submit(object sender, EventArgs e)
        {
            if (validate())
            {
                String OrderId = txtOrderId.Text.Trim();
                String[] orderIds = OrderId.Split(',');
                List<OrderInfo> orderInformation = new List<OrderInfo>();
                orderInformation = GetOrderInfo(orderIds);

                StringBuilder OrderIdsNotFound = new StringBuilder();


                if (orderInformation == null || orderInformation.Count() == 0)
                {
                    displayNoOrderFoundError();
                }
                else
                {
                    foreach (string ordId in orderIds)
                    {
                        if (!orderInformation.Exists(od => od.OrderNumber.Equals(ordId)))
                        {
                            if (OrderIdsNotFound.Length == 0)
                                OrderIdsNotFound.Append(ordId);
                            else
                                OrderIdsNotFound.Append(", " + ordId);
                        }
                    }
                    rptOrdersTable.DataSource = orderInformation;
                    rptOrdersTable.DataBind();
                }

                if (OrderIdsNotFound.Length > 0)
                {
                    lblOrdersNotFound.Text = "No orders was found for the order "  + (OrderIdsNotFound.ToString().Split(',').Length > 1? "numbers ": "number ") + OrderIdsNotFound.ToString();
                }

            }
        }

        public Boolean validate()
        {
            if (String.IsNullOrEmpty(txtOrderId.Text))
            {
                displayError("OrderId");
                return false;
            }
            return true;

        }

        public void displayError(string fieldName)
        {
            string script = "alert(\"Please enter the " + fieldName + " to get the order information\");";
            ScriptManager.RegisterStartupScript(this, GetType(),
                                  "ServerControlScript", script, true);
        }

        public void displayNetworkError()
        {
            string script = "alert(\"Error in Network!\");";
            ScriptManager.RegisterStartupScript(this, GetType(),
                                  "ServerControlScript", script, true);
        }

        public void displayNoOrderFoundError()
        {
            string script = "alert(\"No Orders Found!\");";
            ScriptManager.RegisterStartupScript(this, GetType(),
                                  "ServerControlScript", script, true);
        }

   
    }
}