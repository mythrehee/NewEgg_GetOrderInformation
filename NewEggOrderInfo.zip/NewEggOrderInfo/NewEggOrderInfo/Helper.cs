﻿using Newegg.Marketplace.SDK.Order;
using Newegg.Marketplace.SDK.Order.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NewEggOrderInfo
{
    public static class Helper 
    {
        private static  OrderCall ordercall;

        public static  OrderCall Ordercall { get => ordercall; set => ordercall = value; }

    }
}